﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","hr",{title:"Informacije elementa",dialogName:"Naziv prozora za dijalog",tabName:"Naziva jahača",elementId:"ID elementa",elementType:"Vrsta elementa"});