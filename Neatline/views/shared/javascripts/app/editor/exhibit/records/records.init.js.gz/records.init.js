
/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Editor.Exhibit.Records', function(
  Records, Neatline, Backbone, Marionette, $, _) {


  Records.ID = 'EDITOR:EXHIBIT:RECORDS';


  Records.addInitializer(function() {
    Records.__collection =  new Neatline.Shared.Record.Collection();
    Records.__router =      new Records.Router();
    Records.__view =        new Records.View();
  });


});
